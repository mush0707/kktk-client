<template>
  <div id="add-edit-storage-modal" tabindex="-1" aria-hidden="true"
       class="bg-slate-800/25 fixed top-0 left-0 right-0 z-50 hidden w-full overflow-x-hidden overflow-y-auto md:inset-0 max-h-full">
    <div class="relative h-screen overflow-y-auto bg-white w-full max-w-4xl ">
      <div class="flex items-center justify-between p-4 rounded-t dark:border-gray-600">

        <p class="text-xl">{{ this.storage ? $t('edit_storage') : $t('new_storage') }}</p>
        <button type="button"
                class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-600 dark:hover:text-white"
                @click="modalObj.hide()">
          <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
               xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd"
                  d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                  clip-rule="evenodd"></path>
          </svg>
          <span class="sr-only">Close modal</span>
        </button>
      </div>
      <div class="px-4 pb-4">
        <form @submit="store" class="flex flex-col gap-y-2">
          <div class="flex flex-col gap-y-2">
            <label>{{ $t('address') }}</label>
            <input type="text" name="address" v-model="form.address"
                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500" />
          </div>
          <div class="flex items-center" v-if="!form.industrial">
            <input :disabled="storage" v-model="form.cell" id="cell-checkbox" type="checkbox" value="" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded-sm focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600">
            <label for="cell-checkbox" class="ms-2 text-sm font-medium text-gray-900 dark:text-gray-300">{{ $t('cell') }}</label>
          </div>
          <div class="flex items-center" v-if="!form.cell">
            <input :disabled="storage" v-model="form.industrial" id="industrial-checkbox" type="checkbox" value="" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded-sm focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600">
            <label for="industrial-checkbox" class="ms-2 text-sm font-medium text-gray-900 dark:text-gray-300">{{ $t('industrial') }}</label>
          </div>
          <div>
            <button v-if="!loading" type="button" @click="store"
                    class="text-white bg-indigo-700 hover:bg-indigo-800 focus:ring-4 focus:ring-indigo-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-indigo-600 dark:hover:bg-indigo-700 focus:outline-none dark:focus:ring-indigo-800">
              {{ $t('save') }}
            </button>
            <button v-else type="button"
                    class="text-white flex justify-center bg-indigo-700 hover:bg-indigo-800 focus:ring-4 focus:ring-indigo-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-indigo-600 dark:hover:bg-indigo-700 focus:outline-none dark:focus:ring-indigo-800">
              <svg aria-hidden="true" class="w-6 h-6 text-gray-200 animate-spin dark:text-gray-600 fill-indigo-600" viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z" fill="currentColor"/>
                <path d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z" fill="currentFill"/>
              </svg>
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>
<script>
import {Modal} from "flowbite";
import api from "@/utils/api.js";
import {useToast} from "vue-toastification";
const toast = useToast();

export default {
  components: {},
  data() {
    return {
      modalObj: null,
      form: {
        address: null,
        industrial: false,
        cell: false,
      },
      loading: false,
      sections: [],
      unitOptions: ["սմ", "մմ", "մ"]
    }
  },
  props: ['storage'],
  emits: ['updateList'],
  methods: {
    store() {
      this.loading = true;
      let url = 'storages';
      if(this.storage) {
        url += '/' + this.storage.id;
      }
      api.post(url, {
        address: this.form.address,
        industrial: this.form.industrial ? 1 : 0,
        cell: this.form.cell ? 1 : 0,
      }).then((response) => {
        this.loading = false;
        toast.success(this.$t('storage_successfully_created'));
        this.modalObj.hide();
        this.$emit('updateList')
      }).catch((response) => {
        this.loading = false;
      })
    },
  },
  mounted() {
    this.modalObj = new Modal(document.getElementById('add-edit-storage-modal'), {
      placement: 'top-right',
      closable: true, backdropClasses: 'bg-gray-900/50 dark:bg-gray-900/80 fixed inset-0 z-40 modal-backdrop',
      onHide: () => {
        this.$parent.showAddEditStorage = false;
      },
    })
    this.modalObj.show();
    if(this.storage) {
      this.form = this.storage;
      if(this.form.cell) {
        this.form.cell = true;
      } else if(this.form.industrial) {
        this.form.industrial = true;
      }
    }
  }
}
</script>
